<?php
$codEmail= $_POST["codEmail"];
$codPassword= $_POST["codPassword"];
$codNome= $_POST["codNome"];
$codCognome = $_POST["codCognome"];
$codtarga=$_POST["codtarga"];
$codmetodopagamento= $_POST["codmetodopagamento"];
$codoradiarrivo= $_POST["codoradiarrivo"];

$db="localhost";
$db_user="root";
$db_name="garage";

$conn= mysqli_connect($db, $db_user, '', $db_name) or die("Impossibile connettersi al Database");
$query= "INSERT INTO auto (codNome, codCognome, codtarga, codmetodopagamento, codoradiarrivo, codEmail, codPassword) VALUES ('$codNome','$codCognome', '$codtarga', '$codmetodopagamento', '$codoradiarrivo' , '$codEmail' , '$codPassword')";
$invia= mysqli_query($conn, $query);
if($invia) 	{
	echo $codNome." è stato registrato!";
	} else {
		echo $codNome." non ti sei registrato" ;
		echo "Errore= " . mysqli_error($conn);
 }
 ?>
 <a href="loginAuto.html" class="myButton"> Vai alla mia area privata</a>