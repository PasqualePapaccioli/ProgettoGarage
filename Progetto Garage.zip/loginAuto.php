<?php
 session_start();
   $codEmail=$_POST['codEmail'];
   $codPassword=$_POST['codPassword'];

 $conn= mysqli_connect("localhost","root", "", "garage") or die("Impossibile connettersi al Database");

      $sql = "SELECT 'codEmail','codPassword' FROM auto WHERE codEmail = '$codEmail' AND codPassword = '$codPassword'";
      $result = mysqli_query($conn,$sql);

      $row = mysqli_num_rows($result);



      if($row == 1) {
        $_SESSION['codEmail']=$_POST['codEmail'];
        $_SESSION['codPassword']=$_POST['codPassword'];


      header("Location: AreaprivataA.php");
      }else {
         echo "L'email o Password non sono corretti";
      }

?>