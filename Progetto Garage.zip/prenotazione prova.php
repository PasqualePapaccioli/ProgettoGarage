<?php
$codOraselezionataU= $_POST["codOraselezionataU"];
$codIDPRENOTAZIONE= $_POST["codIDPRENOTAZIONE"];

$db="localhost";
$db_user="root";
$db_name="garage";

$conn= mysqli_connect($db, $db_user, '', $db_name) or die("Impossibile connettersi al Database");
$query= "INSERT INTO prenotazione prova ( `codOraselezionataU` , `codIDPRENOTAZIONE `) VALUES('$codOraselezionataU' , '$codIDPRENOTAZIONE' )";
$invia= mysqli_query($conn, $query);
if($invia) 	{
	echo $codOraselezionataU."Si è registrata la tua Prenotazione";
	} else {
		echo $codOraselezionataU."Non si è registrata la tua Prenotazione" ;
		echo "Errore= " . mysqli_error($conn);
 }
 ?>
 <a href="AreaprivataM.php" class="myButton"> Vai alla mia area privata</a>